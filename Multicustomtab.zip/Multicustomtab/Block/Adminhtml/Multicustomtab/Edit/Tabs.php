<?php

namespace Commercepundit\Multicustomtab\Block\Adminhtml\Multicustomtab\Edit;

class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected function _construct()
    {
        parent::_construct();
        $this->setId('multicustomtab_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Customtab Information'));
    }
}
