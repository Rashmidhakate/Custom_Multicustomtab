<?php

namespace Commercepundit\Multicustomtab\Block\Adminhtml\Multicustomtab\Edit\Tab;

class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    protected $store;
    protected $_wysiwygConfig;
    protected $_helper;
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Commercepundit\Multicustomtab\Helper\Data $helper,
        \Magento\Store\Model\System\Store $systemStore,
        array $data = []
    ) {
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_helper = $helper;
        $this->_systemStore = $systemStore;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('multicustomtab_item');

        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('multicustomtab_');

        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('General Information'), 'class' => 'fieldset-wide']
        );

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }
        $fieldset->addField(
            'title',
            'text',
            [
                'name' => 'title',
                'label' => __('Title'),
                'title' => __('Title'),
                'required' => true
            ]
        );
         $fieldset->addField(
            'sort_order',
            'text',
            [
                'name' => 'sort_order',
                'label' => __('SortOrder'),
                'title' => __('SortOrder'),
                'required' => true
            ]
        );
        $fieldset->addField(
            'store_id',
            'multiselect',
            [
                'name'     => 'store_id[]',
                'label'    => __('Store Views'),
                'title'    => __('Store Views'),
                'required' => true,
                'values'   => $this->_systemStore->getStoreValuesForForm(false, true),
            ]
        );
        //$model->setData('store_id', $this->getRequest()->getParam('store')); 
        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('General Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('General Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    public function getAmountWord(){
        $html = '';
        $html .= '\'input-text required-entry validate-length maximum-length-' . $this->_helper->getAmountWord() .' minimum-length-1\'';
        return $html;
    }

    public function getAfterImageElementHtml($field, $image)
    {
        $html = '';
        $html .= '<p style="margin-top: 5px">';
        $html .= '<image style="min-width: 300px;" src="' . $this->_helper->getImageUrl($image) . '" />';
        //$html .= '<input type="hidden" value="' . $image . '" name="old_' . $field . '"/>';
        $html .= '</p>';
        return $html;
    }
}
