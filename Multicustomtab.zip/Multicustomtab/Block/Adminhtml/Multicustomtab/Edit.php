<?php 
namespace Commercepundit\Multicustomtab\Block\Adminhtml\Multicustomtab;
 
class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    protected $_coreRegistry = null;
 
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }
 
    protected function _construct()
    {
        $this->_objectId = 'id';
        $this->_blockGroup = 'Commercepundit_Multicustomtab';
        $this->_controller = 'adminhtml_multicustomtab';
 
        parent::_construct();
 
        $this->buttonList->update('save', 'label', __('Save CustomTab'));
        $this->buttonList->update('delete', 'label', __('Delete CustomTab'));
 
        $this->buttonList->add(
            'saveandcontinue',
            [
                'label' => __('Save and Continue Edit'),
                'class' => 'save',
                'data_attribute' => [
                    'mage-init' => ['button' => ['event' => 'saveAndContinueEdit', 'target' => '#edit_form']],
                ]
            ],
            -100
        );
 
    }
 
 
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('multicustomtab_item')->getId()) {
            return __("Edit Block '%1'", $this->escapeHtml($this->_coreRegistry->registry('multicustomtab_item')->getName()));
        } else {
            return __('New Customtab');
        }
    }
}