<?php 
namespace Commercepundit\Multicustomtab\Block\Adminhtml;
 
class Multicustomtab extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_blockGroup = 'Commercepundit_Multicustomtab';
        $this->_controller = 'adminhtml_multicustomtab';
        $this->_headerText = __('Multicustomtab');
        $this->_addButtonLabel = __('Add Multicustomtab');
        parent::_construct();
    }
}
