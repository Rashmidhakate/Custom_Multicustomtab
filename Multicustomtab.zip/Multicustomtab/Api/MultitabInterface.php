<?php
namespace Commercepundit\Multicustomtab\Api;

interface MultitabInterface {

	/**
     * Get Customer Data.
     *
     * @param int $Id 
     * @return array
     */
    public function getCollection($Id);
}