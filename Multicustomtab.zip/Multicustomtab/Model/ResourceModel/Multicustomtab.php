<?php
namespace Commercepundit\Multicustomtab\Model\ResourceModel;
use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class Multicustomtab extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('commercepundit_multicustomtab','id');
    }
}

