<?php
namespace Commercepundit\Multicustomtab\Model\ResourceModel\Multicustomtab;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	
    protected function _construct()
    {
        $this->_init('Commercepundit\Multicustomtab\Model\Multicustomtab','Commercepundit\Multicustomtab\Model\ResourceModel\Multicustomtab');
    }
    public function toOptionArray()
	{
		return $this->_toOptionArray('id', 'title');
	}
}