<?php
/**
 * My own options
 *
 */
namespace Commercepundit\Multicustomtab\Model\Config\Source;

class Options implements \Magento\Framework\Option\ArrayInterface
{
    public function __construct(
        \Magento\Cms\Model\BlockFactory $blockFactory,
        \Magento\Cms\Model\ResourceModel\Block\Collection $blockColFactory
    ){
        $this->_blockFactory = $blockFactory;
        $this->blockColFactory = $blockColFactory;
    }
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = $this->blockColFactory->toOptionArray();
        return $options;
    }
}
 
