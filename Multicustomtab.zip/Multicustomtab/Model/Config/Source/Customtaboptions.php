<?php
/**
 * My own options
 *
 */
namespace Commercepundit\Multicustomtab\Model\Config\Source;

class Customtaboptions implements \Magento\Framework\Option\ArrayInterface
{
    public function __construct(
        \Commercepundit\Multicustomtab\Model\ResourceModel\Multicustomtab\Collection $multicustomtabCollection
    ){
        $this->multicustomtabCollection = $multicustomtabCollection;
    }
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = $this->multicustomtabCollection->toOptionArray();
        return $options;
    }
}
 
