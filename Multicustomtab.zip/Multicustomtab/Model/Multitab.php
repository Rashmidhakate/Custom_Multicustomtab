<?php
namespace Commercepundit\Multicustomtab\Model;

use \Commercepundit\Multicustomtab\Model\ResourceModel\Multicustomtab as tabsCollectionFactory;
use \Commercepundit\Multicustomtab\Helper\Data;
use \Commercepundit\Multicustomtab\Api\MultitabInterface as ApiInterface;
 
class Multitab implements \Commercepundit\Multicustomtab\Api\MultitabInterface {
 
    
    public function __construct(
       \Commercepundit\Multicustomtab\Model\MulticustomtabFactory $MulticustomtabFactory,
        \Commercepundit\Multicustomtab\Model\ResourceModel\Multicustomtab\CollectionFactory $tabsCollectionFactory
    ) {
        $this->MulticustomtabFactory = $MulticustomtabFactory;
        $this->tabsCollectionFactory = $tabsCollectionFactory;
    }
 
    /**
     * Updates the specified cart with the specified products.
     *
     * @api
     * @param int $cartId
     * @param \Custom\Restapi\Api\CartProductInformationInterface $products
     * @return boolean
     */
    public function getCollection($Id) {
        $resultPage = $this->MulticustomtabFactory->create();
        $collection = $resultPage->getCollection();
        $collection->addFieldToFilter('id',array('in'=>$Id));
        return $collection->getData();
    }
}