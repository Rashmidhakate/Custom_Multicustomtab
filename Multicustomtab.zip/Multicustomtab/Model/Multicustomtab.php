<?php
namespace Commercepundit\Multicustomtab\Model;

class Multicustomtab extends \Magento\Framework\Model\AbstractModel
{
	  protected $_eventsCollectionFactory;

   
    protected $_storeViewId = null;

    
    protected $_eventsFactory;

   
    protected $_formFieldHtmlIdPrefix = 'page_';

    
    protected $_storeManager;

   
    protected $_monolog;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Logger\Monolog $monolog
    ) {
        parent::__construct(
            $context,
            $registry
        );
        $this->_storeManager = $storeManager;
        $this->_monolog = $monolog;

        if ($storeViewId = $this->_storeManager->getStore()->getId()) {
            $this->_storeViewId = $storeViewId;
        }
    }

    protected function _construct()
    {
        $this->_init('Commercepundit\Multicustomtab\Model\ResourceModel\Multicustomtab');
    }
}

