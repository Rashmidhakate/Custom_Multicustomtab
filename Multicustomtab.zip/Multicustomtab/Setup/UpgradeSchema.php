<?php

namespace Commercepundit\Multicustomtab\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $tableName = $setup->getTable('commercepundit_multicustomtab');
        if (version_compare($context->getVersion(), '2.0.1') < 0) {
            //$tableName = $installer->getTable('cp_newsmodule');
            $fullTextIntex = array('title'); // Column with fulltext index, you can put multiple fields

            $setup->getConnection()->addIndex(
                $tableName,
                $setup->getIdxName($tableName, $fullTextIntex, \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT),
                $fullTextIntex,
                \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
            );

        } 
        if (version_compare($context->getVersion(), '2.0.2', '<')) {
          $setup->getConnection()->addColumn(
                $setup->getTable('commercepundit_multicustomtab'),
                'store_id',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    'length' => 10,
                    'nullable' => true,
                    'comment' => 'Store Id'
                ]
            );
        }
        $setup->endSetup();
    }
}