<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Commercepundit\Multicustomtab\Controller\Adminhtml\Index;

use Magento\Cms\Model\Wysiwyg as WysiwygModel;
use Magento\Framework\App\RequestInterface;
use Magento\Store\Model\StoreFactory;
use Psr\Log\LoggerInterface as Logger;
use Magento\Framework\Registry;

class Builder
{
    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;

    /**
     * @var \Magento\Cms\Model\Wysiwyg\Config
     */
    protected $wysiwygConfig;

    /**
     * @var StoreFactory
     */
    protected $storeFactory;

    /**
     * Constructor
     *
     * @param ProductFactory $productFactory
     * @param Logger $logger
     * @param Registry $registry
     * @param WysiwygModel\Config $wysiwygConfig
     * @param StoreFactory|null $storeFactory
     */
    public function __construct(
        Logger $logger,
        Registry $registry,
        WysiwygModel\Config $wysiwygConfig,
        \Commercepundit\Multicustomtab\Model\Multicustomtab $multicustomtab,
        StoreFactory $storeFactory = null
    ) {
        $this->logger = $logger;
        $this->registry = $registry;
        $this->wysiwygConfig = $wysiwygConfig;
        $this->multicustomtab = $multicustomtab;
        $this->storeFactory = $storeFactory ?: \Magento\Framework\App\ObjectManager::getInstance()
            ->get(\Magento\Store\Model\StoreFactory::class);
    }

    /**
     * Build product based on user request
     *
     * @param RequestInterface $request
     * @return \Magento\Catalog\Model\Product
     */
    public function build(RequestInterface $request)
    {
        $Id = (int)$request->getParam('id');
        $model = $this->multicustomtab;

        /** @var $product \Magento\Catalog\Model\Product */
        // $product = $this->productFactory->create();
        $model->setStoreId($request->getParam('store', 0));
        $store = $this->storeFactory->create();
        $store->load($request->getParam('store', 0));

        if ($Id) {
            try {
                $model->load($Id);
            } catch (\Exception $e) {
                $this->logger->critical($e);
            }
        }

        $this->registry->register('product', $product);
        $this->registry->register('current_product', $product);
        $this->registry->register('current_store', $store);
        $this->wysiwygConfig->setStoreId($request->getParam('store'));
        return $product;
    }
}
