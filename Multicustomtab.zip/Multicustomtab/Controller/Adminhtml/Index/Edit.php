<?php

namespace Commercepundit\Multicustomtab\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;

class Edit extends Action
{
    const ADMIN_RESOURCE = 'Commercepundit_Multicustomtab::save';
    protected $_coreRegistry = null;
    protected $resultPageFactory;

    public function __construct(Action\Context $context, PageFactory $resultPageFactory, Registry $registry)
    {
        $this->_coreRegistry = $registry;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
    }

    protected function _initAction()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Commercepundit_Multicustomtab::menu_item')
            ->addBreadcrumb(__('CustomTab'), __('CustomTab'))
            ->addBreadcrumb(__('New CustomTab'), __('New CustomTab'));
        return $resultPage;
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $model = $this->_objectManager->create('Commercepundit\Multicustomtab\Model\Multicustomtab');
        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This News no longer exists.'));
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }
        
        $data = $this->_objectManager->get('Magento\Backend\Model\Session')->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        $this->_coreRegistry->register('multicustomtab_item', $model);

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_initAction();
        $resultPage->addBreadcrumb(
            $id ? __('Edit CustomTab') : __('New CustomTab'),
            $id ? __('Edit CustomTab') : __('New CustomTab')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('CustomTab Edit'));

        return $resultPage;
    }
}




