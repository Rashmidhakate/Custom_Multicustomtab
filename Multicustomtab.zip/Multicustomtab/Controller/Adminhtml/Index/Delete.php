<?php

namespace Commercepundit\Multicustomtab\Controller\Adminhtml\Index;
use Magento\Backend\App\Action;
use Magento\Framework\Exception\LocalizedException;

class Delete extends \Magento\Backend\App\Action {

	const ADMIN_RESOURCE = 'Commercepundit_Multicustomtab::event_delete';

	public function __construct(Action\Context $context) {
		parent::__construct($context);
	}

	public function _isAllowed() {
		return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
	}

	public function execute() {
		$id = $this->getRequest()->getParam('id');
		if ($id) {
			try {
				$model = $this->_objectManager->create('Commercepundit\Multicustomtab\Model\Multicustomtab');
				$model->load($id);
				$model->delete();
				$this->_redirect('multicustomtab/*/');
				$this->messageManager->addSuccess(__('Deleted CustomTab successfully.'));
				return;
			} catch (LocalizedException $e) {
				$this->messageManager->addError($e->getMessage());
			} catch (\Exception $e) {
				$this->messageManager->addError(
					__('We can\'t delete this News right now. Please review the log and try again.')
				);
				$this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
				$this->_redirect('multicustomtab/*/edit', ['id' => $this->getRequest()->getParam('id')]);
				return;
			}
		}
		$this->messageManager->addError(__('We can\'t find a rule to delete.'));
		$this->_redirect('multicustomtab/*/');
	}
}
